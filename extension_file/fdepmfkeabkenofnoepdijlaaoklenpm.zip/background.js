chrome.browserAction.onClicked.addListener(function(tab) {
  chrome.tabs.create({
    url: "https://jordiob.com/amazon-tools/"
  });
});
